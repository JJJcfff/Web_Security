window.onload = function () {
  document.getElementById("query").onfocus = function () {
    this.value = "";
  };
};
