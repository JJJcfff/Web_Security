window.onload = function () {
    setTimeout(function() { window.location = '/'; }, 5000);
}