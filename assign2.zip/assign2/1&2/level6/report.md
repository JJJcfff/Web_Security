Patch:
I added a line in the choose tab 
**num = num.match(/^\d+$/) ? num : "1";**
---

App is based on python 3.11 and Flask

To run the app, 
Simply run the following command in the terminal:
```bash
python ./level6.py
```
and go to http://127.0.0.1:5000/

