Patch:
I used render_template_string of flask to render the template,
which automatically escapes user input.

---

App is based on python 3.11 and Flask

To run the app, 
Simply run the following command in the terminal:
```bash
python ./level1.py
```
and go to http://127.0.0.1:5000/

