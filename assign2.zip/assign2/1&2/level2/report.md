Patch:
I used DomPurify to sanitize the user input when displaying it on the page.

---

App is based on python 3.11 and Flask

To run the app, 
Simply run the following command in the terminal:
```bash
python ./level6.py
```
and go to http://127.0.0.1:5000/

